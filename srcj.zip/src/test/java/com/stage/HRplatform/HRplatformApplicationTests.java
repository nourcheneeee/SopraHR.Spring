package com.stage.HRplatform;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HRplatformApplicationTests {

	@Test
	void contextLoads() {
	}

}
