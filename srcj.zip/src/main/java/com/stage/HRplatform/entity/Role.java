package com.stage.HRplatform.entity;

public enum Role {
    ADMIN,
    EMPLOYEE,
}