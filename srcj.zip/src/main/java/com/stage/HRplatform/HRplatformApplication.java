package com.stage.HRplatform;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HRplatformApplication {

	public static void main(String[] args) {

		SpringApplication.run(HRplatformApplication.class, args);
	}

}
